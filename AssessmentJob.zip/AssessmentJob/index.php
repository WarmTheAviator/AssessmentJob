<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>sigmasigmaboy</title>
        <link rel="stylesheet" href="styles.css">
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    </head>

    <body>
        <!--Header Section-->
        <header>
            <div id="navbar" class="obj-width">
                <a href="index.html"><img class="logo" src="images/logo.png" alt=""></a>

                <ul id="menu">
                    <li><a href="">Home</a></li>
                    <li><a href="jobs/jobpage.php">Browse Jobs</a></li>
                    <li><a href="contact/contactpage.php">Contact Us</a></li> 
                    <?php if (isset($_SESSION["user"])): ?>
                            
                            <button id="w-btn"><a href="logout.php">Welcome <?php echo htmlspecialchars($_SESSION["user"]); ?></a></button>
                         
                        <?php elseif (is_null($_SESSION["user"])): ?>
                            <button id="w-btn"><a href="LoginReg/Login.html">Join</a></button>
                        <?php endif; ?>

                    
                </ul>

                <i id="bar" class='bx bx-menu'></i>
            </div>
        </header>

        <!--Hero Section, Main!-->

        <section class="hero">
            <div class="hero-box obj-width"> 
                <div class="h-left">
                    <h1>Find the perfect employment position for you!</h1>
                    <p>Work with like-minded people, guaranteed efficiency</p>
                    <div class="search">
                        <input type="text" placeholder="Search your job here!">
                        <a id="g-btn" href="#">Search</a>
                    </div>
                </div>

                <div class="h-right">
                    <img src="images/hero1.png"alt="">
                </div>
            </div>
        </section>

        <!--FEATURES-->

        <section class="features sec-space obj-width">
            <h2>Need sometihng done?</h2>
            <p>Most viewed and all time top selling services</p>

            <div class="fe-box">
                <div>
                    <img src="images/fe 1.png" alt="">
                    <h3>Post a Job</h3>
                    <p>It's free and easy to post a job. Simply fill in a title, description</p>
                </div>
                <div>
                    <img src="images/fe 2.png" alt="">
                    <h3>Work Independently</h3>
                    <p>Horrible Workmates? No Worries! Multiple Independent Contracts!</p>
                </div>
                <div>
                    <img src="images/fe 3.png" alt="">
                    <h3>Pay Safely</h3>
                    <p>It's free and easy to post a job. Simply fill in a title, description</p>
                </div>
                <div>
                    <img src="images/fe 4.png" alt="">
                    <h3>We're here to help</h3>
                    <p>It's free and easy to post a job. Simply fill in a title, description</p>
                </div>
            </div>
        </section>

        <!--JOB LISTING SECTION DIGGERS-->
        <section class="jobs sec-space obj-width">
            <h2>Jobs Available</h2>
            <p>Most viewed and all-time top-selling services</p>

            <ul class="job-id">
                <li data-target="all" class="active">Recent Listings</li>
                <li data-target="Freelancer">Freelancer</li>
                <li data-target="fulltime">Full time</li>
                <li data-target="partTime">Part Time</li>
            </ul>

            <div class="jobs-container">
                <li data-item="all" class="jList">
                    <img src="images/google.png" alt="">
                    <h3>Web Developer</h3>
                    <p>1 million doller</p>
                    <span id="key">Time</span>
                </li>
                <li data-item="Freelancer" class="jList">
                    <img src="images/google.png" alt="">
                    <h3>Freelancer</h3>
                    <p>2 million doller</p>
                    <span id="key">Flexible</span>
                </li>
                <li data-item="fulltime" class="jList">
                    <img src="images/google.png" alt="">
                    <h3>Digital Marketing</h3>
                    <p>3 million doller</p>
                    <span id="key">Full Time</span>
                </li>
                <li data-item="partTime" class="jList">
                    <img src="images/google.png" alt="">
                    <h3>Business Associate</h3>
                    <p>4 million doller</p>
                    <span id="key">Part Time</span>
                </li>
            </div>
        </section>

        <!--Brand Section-->

        <section class="trust sec-space obj-width">
            <h2>Trusted globally!</h2>
            <p>Most viewed and all-time top-selling services </p>

            <div class="t-box">
                <img src="images/t1.png" alt="">
                <img src="images/t2.png" alt="">
                <img src="images/t3.png" alt="">
                <img src="images/t4.png" alt="">
                <img src="images/t5.png" alt="">
                <img src="images/t6.png" alt="">
            </div>
        </section>

        <section class="team sec-space obj-width">
            <h2>Top Applicants!</h2>
            <p>Most viewed and all-time top-selling services </p>

            <div class="team-container">
                <div class="fl-box">
                    <img src="images/fl-1.png" alt="">
                    <h3>name</h3>
                    <div class="skill">
                        <span id="key">HTML</span>
                        <span id="key">CSS</span>
                        <span id="key">JS</span>
                    </div>

                    <a href="#" id="g-btn">View Profile</a>
                </div>

                <div class="fl-box">
                    <img src="images/fl-2.png" alt="">
                    <h3>name</h3>
                    <div class="skill">
                        <span id="key">HTML</span>
                        <span id="key">CSS</span>
                        <span id="key">JS</span>
                    </div>

                    <a href="#" id="g-btn">View Profile</a>
                </div>

                <div class="fl-box">
                    <img src="images/fl-3.png" alt="">
                    <h3>name</h3>
                    <div class="skill">
                        <span id="key">HTML</span>
                        <span id="key">CSS</span>
                        <span id="key">JS</span>
                    </div>

                    <a href="#" id="g-btn">View Profile</a>
                </div>

                <div class="fl-box">
                    <img src="images/fl-4.png" alt="">
                    <h3>name</h3>
                    <div class="skill">
                        <span id="key">HTML</span>
                        <span id="key">CSS</span>
                        <span id="key">JS</span>
                    </div>

                    <a href="#" id="g-btn">View Profile</a>
                </div>
            </div>
        </section>

        <!--Footer Section-->

        <footer class="footer">
            <div class="obj">
                <div class="top">
                    <div>
                        <img class="logo" src="images/logo.png" alt="">
                        <p>Search your desired jobs.</p>
                    </div>
                    <div>
                        <a href="https://www.instagram.com/reel/DEMJWowMfMs/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA=="><i class='bx bxl-instagram-alt'></i></a>
                        <a href="https://www.instagram.com/reel/DEMJWowMfMs/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA=="><i class='bx bxl-behance'></i></a>
                        <a href="https://www.instagram.com/reel/DEMJWowMfMs/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA=="><i class='bx bxl-facebook-square'></i></a>
                        <a href="https://www.instagram.com/reel/DEMJWowMfMs/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA=="><i class='bx bxl-twitter'></i></a>
                    </div>
                </div>
            </div>
        </footer>










        <script src="toggle.js"></script>
        <script src="script.js"></script>
    </body> 
</html>
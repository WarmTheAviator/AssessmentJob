<?php
    session_start();
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Database connection
   $conn = new mysqli('localhost','Registration','','AssessmentJob');
   if($conn->connect_error){
       echo "$conn->connect_error";
       die("Connection Failed : ". $conn->connect_error);
   } else {
        //From the Registration Database we will find an email
        $sql = "SELECT * FROM Registration WHERE email = '$email' AND password = '$password'";

        $result = mysqli_query($conn, $sql);    

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if($row['email'] === $email && $row['password'] === $password) {
                $_SESSION["user"] = $row['email'];
                header("Location: ../index.php");
                echo json_encode(["status" => "success"]);
                exit();
            }
        }
    }
?>